Kindle 4 修砖记 — source archive

Download and inspect source only; this site does not run the experience.

The local HTML and md5-min.js retain their relative paths. md5-min.js retains its Paul Johnston 1999–2009, contributors and BSD notice. The calculator targets historical Kindle firmware; compatibility or safe device recovery is not promised.

Original files and notices are preserved without modification. No offline completeness, execution safety, future restoration or additional rights are promised. Do not execute legacy code in a trusted browser profile.
