Google 图标：动态雕塑家 Calder 诞辰 113 周年 — source archive

Download and inspect source only; this site does not run the experience.

The Doodle uses legacy Canvas JavaScript (including eval), Google search navigation and an external Google fallback image. External resources are NOT included. The original HTML retains the Calder Foundation / ARS, NY credit. No new license is granted.

Original files and notices are preserved without modification. No offline completeness, execution safety, future restoration or additional rights are promised. Do not execute legacy code in a trusted browser profile.
