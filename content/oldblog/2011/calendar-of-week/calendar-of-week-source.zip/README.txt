星期万年历 — source archive

Download and inspect source only; this site does not run the experience.

The HTML refers to unpinned //code.jquery.com/jquery-latest.js. That external dependency is NOT included. The local HTML, CSS and JavaScript remain together with unchanged relative paths.

Original files and notices are preserved without modification. No offline completeness, execution safety, future restoration or additional rights are promised. Do not execute legacy code in a trusted browser profile.
