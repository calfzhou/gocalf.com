自动机编程游戏：Manufactoria（流水线编程） — source archive

Download and inspect source only; this site does not run the experience.

Only the locally preserved SWF and original article/solution text are available, not the game authoring source. The SWF needs an obsolete Flash runtime; modern browser playability is NOT provided. The original external embed points to pleasingfungus.com; no external content was fetched. Game rights remain with their respective owners.

Original files and notices are preserved without modification. No offline completeness, execution safety, future restoration or additional rights are promised. Do not execute legacy code in a trusted browser profile.
